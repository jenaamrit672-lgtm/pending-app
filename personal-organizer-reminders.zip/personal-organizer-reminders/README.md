# Personal Organizer — revision reminders for Web + Android

This is a runnable starter project, not a published app. It includes a responsive web interface, a Progressive Web App shell, local data storage, JSON backup/restore, and a Capacitor Android build path.

## Features in this starter

- Add a subject and topic with the study date and time.
- Automatically calculate reviews at +24 hours, +72 hours, +7 days and +30 days.
- Mark each review complete; completed reminders are not scheduled again.
- Android local notifications through `@capacitor/local-notifications`.
- Browser notification permission and a test notification while the page is open.
- Tasks and schedule lists.
- Local data and JSON backup/restore.

## Important capability distinction

### Works in the web prototype
- Review-date calculation, due/upcoming/completed lists, tasks and schedule.
- Data persistence in that browser's local storage.
- JSON export/import.
- PWA shell caching after the first successful load on HTTPS/localhost.

### Works after building and installing the Android app
- Native local notifications can be scheduled on the device for the four review times, even when the app is not open, subject to Android permission, exact-alarm/battery behavior and device settings.
- This project uses Capacitor's Local Notifications plugin. Android Studio/Android SDK are required to build the APK.

### Requires extra deployment/backend work
- Reliable web push notifications while the browser/site is closed. That requires HTTPS hosting, a push subscription flow, VAPID keys, a push service and a backend job/queue to send notifications at the due time. A service worker alone cannot guarantee scheduled notifications.
- Student accounts, cross-device cloud sync and shared data are not included.
- This starter stores data locally; it does not sync or automatically merge browser and Android data.

## Run the website locally

Install Node.js (LTS), then from this project directory:

```bash
npm install
npm run web
```

Open the localhost URL Vite prints. For a production web build:

```bash
npm run build
```

Host the `dist/` directory on an HTTPS static host for PWA installation. Web push while closed is not enabled by this build.

## Build for Android

You need Node.js LTS, Android Studio, and Android SDK tools.

```bash
npm install
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

In Android Studio, let Gradle sync, choose a device/emulator, and run the app. To create an APK, use Android Studio's Build menu. For later web-code changes:

```bash
npm run build
npx cap sync android
```

The native notification permission is requested when scheduling reminders. Test on a physical device as well as an emulator. Android version, manufacturer battery optimizations and notification settings can affect delivery. Avoid assuming alarms will be exact to the second.

## Data backup

Use **Backup → Export backup** inside the app. Save the JSON file in a safe location. Restore replaces the local data on that installation.

## Notification design

Each topic has four stable notification IDs. Marking a review done cancels its scheduled notifications for that topic and re-schedules remaining unfinished reviews. If the app has been offline or notifications have changed, opening the app refreshes pending schedules.

## Production checklist

Before public release, add app icons, privacy policy, secure cloud auth if needed, automated tests, crash reporting, push backend for web notifications, and Play Store signing/release setup.
