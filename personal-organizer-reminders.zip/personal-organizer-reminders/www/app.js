import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const KEY = 'personal-organizer-reminders-v1';
const intervals = [
  {label:'24-hour review', ms:24*60*60*1000},
  {label:'72-hour review', ms:72*60*60*1000},
  {label:'7-day review', ms:7*24*60*60*1000},
  {label:'30-day review', ms:30*24*60*60*1000}
];
const fresh = () => ({revisions:[],events:[],tasks:[]});
let data = fresh(), filter='all';
try { const raw=localStorage.getItem(KEY); if(raw) data={...fresh(),...JSON.parse(raw)}; } catch {}
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const localDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const now = new Date();
const fmt = d => new Date(d).toLocaleString(undefined,{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'});
const id = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2,7)}`;
const native = () => Capacitor.isNativePlatform();
function save(){localStorage.setItem(KEY,JSON.stringify(data));render();}
function toast(msg){$('toast').textContent=msg;$('toast').classList.remove('hidden');setTimeout(()=>$('toast').classList.add('hidden'),2600);}
function reviewAt(r,i){return new Date(new Date(r.studiedAt).getTime()+intervals[i].ms);}
function state(r,i){if(r.done?.[i])return 'completed';return reviewAt(r,i).getTime()<=Date.now()?'due':'upcoming';}
function reviewNotificationId(r,i){let n=0;for(const c of `${r.id}-${i}`)n=(n*31+c.charCodeAt(0))%2000000000;return n+1;}
async function ensurePermission(){
  if(native()){
    const current=await LocalNotifications.checkPermissions();
    if(current.display==='granted')return true;
    const req=await LocalNotifications.requestPermissions();
    return req.display==='granted';
  }
  if('Notification' in window){
    if(Notification.permission==='granted')return true;
    return (await Notification.requestPermission())==='granted';
  }
  return false;
}
async function cancelNotificationsFor(r){
  if(!native())return;
  try{const ids=intervals.map((_,i)=>({id:reviewNotificationId(r,i)}));await LocalNotifications.cancel({notifications:ids});}catch{}
}
async function scheduleNotifications(r){
  if(!native()||!r.notificationsEnabled)return;
  const permitted=await ensurePermission();
  if(!permitted){toast('Notification permission was not granted. Reviews remain in the app.');return;}
  await cancelNotificationsFor(r);
  const notifications=intervals.map((it,i)=>({id:reviewNotificationId(r,i),title:`Revision due: ${r.topic}`,body:`${r.subject} · ${it.label}`,schedule:{at:reviewAt(r,i)},extra:{revisionId:r.id,step:i},smallIcon:'ic_stat_icon_config_sample'}))
    .filter((n,i)=>!r.done?.[i]&&n.schedule.at.getTime()>Date.now());
  if(notifications.length){try{await LocalNotifications.schedule({notifications});}catch(e){console.error(e);toast('Could not schedule device notifications. Check Android notification settings.');}}
}
async function refreshNotifications(){
  if(!native())return;
  try{
    const pending=await LocalNotifications.getPending();
    const keep=new Set();
    for(const r of data.revisions)for(let i=0;i<4;i++)if(r.notificationsEnabled&&!r.done?.[i]&&reviewAt(r,i)>new Date())keep.add(reviewNotificationId(r,i));
    const stale=pending.notifications.filter(n=>!keep.has(n.id)).map(n=>({id:n.id}));
    if(stale.length)await LocalNotifications.cancel({notifications:stale});
    for(const r of data.revisions)if(r.notificationsEnabled)await scheduleNotifications(r);
  }catch(e){console.warn('Notification refresh:',e);}
}
function showTab(name){
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('hidden',v.id!==`view-${name}`));
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  if(name==='backup')notificationStatus();
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.view)));
function entry(title,meta,buttons=''){
  return `<div class="entry"><div class="entry-title">${title}</div><div class="meta">${meta}</div>${buttons}</div>`;
}
function reviewList(){
  let rows=[];
  data.revisions.forEach(r=>intervals.forEach((it,i)=>rows.push({r,i,status:state(r,i),at:reviewAt(r,i)})));
  if(filter!=='all')rows=rows.filter(x=>x.status===filter);
  rows.sort((a,b)=>({due:0,upcoming:1,completed:2}[a.status]-{due:0,upcoming:1,completed:2}[b.status])||a.at-b.at);
  $('reviews').innerHTML=rows.length?rows.map(({r,i,status,at})=>{
    const pill=status==='due'?'<span class="pill due">Due now</span>':status==='completed'?'<span class="pill done">Completed</span>':'<span class="pill">Upcoming</span>';
    const doneBtn=status==='completed'?'':`<button class="smallbtn" data-done="${esc(r.id)}" data-step="${i}">✓ Mark reviewed</button>`;
    const deleteBtn=`<button class="smallbtn" data-delete-rev="${esc(r.id)}">Delete topic</button>`;
    return entry(esc(r.topic),`${esc(r.subject)} · ${esc(intervals[i].label)}<br>${fmt(at)} ${pill}${r.memo?`<br>${esc(r.memo)}`:''}`,`${doneBtn}${deleteBtn}`);
  }).join(''):'<p class="muted small">Nothing to show here yet. Add a topic above.</p>';
  $('reviews').querySelectorAll('[data-done]').forEach(b=>b.onclick=async()=>{
    const r=data.revisions.find(x=>x.id===b.dataset.done);if(!r)return;
    r.done=r.done||[false,false,false,false];r.done[Number(b.dataset.step)]=true;
    await cancelNotificationsFor(r);save();await scheduleNotifications(r);toast('Review marked complete');
  });
  $('reviews').querySelectorAll('[data-delete-rev]').forEach(b=>b.onclick=async()=>{
    const r=data.revisions.find(x=>x.id===b.dataset.deleteRev);if(!r||!confirm(`Delete "${r.topic}" and its review reminders?`))return;
    await cancelNotificationsFor(r);data.revisions=data.revisions.filter(x=>x.id!==r.id);save();await refreshNotifications();toast('Topic deleted');
  });
}
document.querySelectorAll('[data-view]').forEach(()=>{});
$('filter').addEventListener('change',e=>{filter=e.target.value;reviewList();});
$('revisionForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const dt=new Date(`${$('studiedDate').value}T${$('studiedTime').value}:00`);
  if(Number.isNaN(dt.getTime()))return toast('Please enter a valid study date and time.');
  if(dt.getTime()>Date.now()+60000)return toast('Study date/time cannot be in the future.');
  const r={id:id(),subject:$('subject').value,topic:$('topic').value.trim(),studiedAt:dt.toISOString(),memo:$('memo').value.trim(),done:[false,false,false,false],notificationsEnabled:$('notify').checked};
  data.revisions.unshift(r);save();
  if(native()&&r.notificationsEnabled)await scheduleNotifications(r);
  e.target.reset();$('studiedDate').value=localDate(new Date());$('studiedTime').value=new Date().toTimeString().slice(0,5);$('notify').checked=true;
  await refreshNotifications();toast(native()?'Topic saved; device reminders scheduled where permitted.':'Topic saved. Web reminders show in the app; closed-browser push needs deployment.');
});
$('eventForm').addEventListener('submit',e=>{e.preventDefault();data.events.push({id:id(),title:$('eventTitle').value.trim(),date:$('eventDate').value,time:$('eventTime').value});e.target.reset();$('eventDate').value=localDate(new Date());save();toast('Schedule item saved');});
$('taskForm').addEventListener('submit',e=>{e.preventDefault();data.tasks.unshift({id:id(),title:$('taskTitle').value.trim(),date:$('taskDate').value,done:false});e.target.reset();save();toast('Task saved');});
function render(){
  const all=data.revisions.flatMap(r=>intervals.map((_,i)=>state(r,i)));
  $('dueCount').textContent=all.filter(x=>x==='due').length;$('topicCount').textContent=data.revisions.length;
  reviewList();
  $('events').innerHTML=data.events.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map(e=>entry(esc(e.title),`${esc(e.date)} · ${esc(e.time)}`,`<button class="smallbtn" data-delete-event="${esc(e.id)}">Delete</button>`)).join('')||'<p class="muted small">No schedule items yet.</p>';
  $('events').querySelectorAll('[data-delete-event]').forEach(b=>b.onclick=()=>{data.events=data.events.filter(x=>x.id!==b.dataset.deleteEvent);save();});
  $('tasks').innerHTML=data.tasks.map(t=>entry(`<label><input type="checkbox" data-task="${esc(t.id)}" ${t.done?'checked':''}> ${esc(t.title)}</label>`,t.date?`Due ${esc(t.date)}`:'No due date',`<button class="smallbtn" data-delete-task="${esc(t.id)}">Delete</button>`)).join('')||'<p class="muted small">No tasks yet.</p>';
  $('tasks').querySelectorAll('[data-task]').forEach(b=>b.onchange=()=>{const t=data.tasks.find(x=>x.id===b.dataset.task);if(t)t.done=b.checked;save();});
  $('tasks').querySelectorAll('[data-delete-task]').forEach(b=>b.onclick=()=>{data.tasks=data.tasks.filter(x=>x.id!==b.dataset.deleteTask);save();});
}
async function notificationStatus(){
  let msg;
  if(native()){
    try{const p=await LocalNotifications.checkPermissions();msg=`Android local notifications: ${p.display}. Scheduled reminders can arrive when the app is closed, subject to device settings, battery restrictions and OS behavior.`;}
    catch{msg='Android local notification status unavailable.';}
  }else if(!('Notification' in window)){msg='This browser does not support the Notification API. Review dates remain visible inside the app.';}
  else{msg=`Browser permission: ${Notification.permission}. This web build does not have a push backend, so it cannot reliably notify you while the site/browser is closed.`;}
  $('notifyStatus').textContent=msg;
}
$('testNotify').addEventListener('click',async()=>{
  const ok=await ensurePermission();if(!ok){toast('Notifications not permitted or not supported.');await notificationStatus();return;}
  if(native()){await LocalNotifications.schedule({notifications:[{id:987654,title:'Personal Organizer test',body:'Notifications are working on this device.',schedule:{at:new Date(Date.now()+1500)}}]});toast('Test notification scheduled.');}
  else if('Notification' in window){new Notification('Personal Organizer test',{body:'Browser notifications work while this page is active.'});toast('Test notification sent.');}
  await notificationStatus();
});
$('export').onclick=()=>{
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
  a.href=url;a.download=`personal-organizer-backup-${localDate(new Date())}.json`;a.click();URL.revokeObjectURL(url);$('backupStatus').textContent='Export started. Check your Downloads folder.';
};
$('import').onclick=()=>{
  const file=$('importFile').files[0];if(!file)return toast('Choose a JSON backup first.');
  const reader=new FileReader();reader.onload=async()=>{try{
    const parsed=JSON.parse(reader.result);if(!parsed||!Array.isArray(parsed.revisions)||!Array.isArray(parsed.tasks)||!Array.isArray(parsed.events))throw Error();
    if(!confirm('Restore this backup and replace current local data?'))return;
    if(native()){for(const r of data.revisions)await cancelNotificationsFor(r);}
    data={...fresh(),...parsed};save();await refreshNotifications();$('backupStatus').textContent='Backup restored.';
  }catch{$('backupStatus').textContent='Could not restore: the selected file is not a compatible backup.';}};
  reader.readAsText(file);
};
async function boot(){
  const d=new Date();$('today').textContent=d.toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  $('studiedDate').value=localDate(d);$('studiedTime').value=d.toTimeString().slice(0,5);$('eventDate').value=localDate(d);
  if('serviceWorker' in navigator && !native()){try{await navigator.serviceWorker.register('/sw.js');}catch(e){console.warn('Service worker registration failed',e);}}
  render();await refreshNotifications();await notificationStatus();
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){render();refreshNotifications();}});
}
boot();